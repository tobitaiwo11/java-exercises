package game;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by OLUWATOBI on 11/29/2017.
 */
public abstract class shapes {//abstract class(can be extended into other classes)
    int x;//variables
    int y;
    int x1;
    int y1;
    int x2;
    int y2;
    int x3;
    int y3;
    int x4;
    int y4;
    int x5;
    int y5;
    int counter=0;
    String playername;
    Date date;
    ArrayList<int[]> length=new ArrayList<int[]>();
    ArrayList<int[]> length1=new ArrayList<int[]>();
    int score;






}
