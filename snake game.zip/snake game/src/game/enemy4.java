package game;

/**
 * Created by OLUWATOBI on 12/9/2017.
 */

public class enemy4 extends shapes {//the class enemy4 extends the abstract class shape

    public enemy4(int x, int y){//the constructor enemy4 take 2 values

        this.x5=x;//the values of x5 which is in the abstract class is equals to x(constructor value)

        this.y5=y;//the values of y5 which is in the abstract class is equals to y(constructor value)

    }
}
