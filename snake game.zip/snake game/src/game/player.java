package game;

import java.util.Date;

/**
 * Created by OLUWATOBI on 12/8/2017.
 */
public class player extends shapes {//abstract class shape is extended into player class

    public player(String name, int score, Date date){//player constructor takes 3  arguments
        this.score=score;
        this.playername=name;
        this.date=date;
    }
    public String toString(){//use to convert constructor to string
        return (playername+","+score+","+date);
    }

}
