package game;

/**
 * Created by OLUWATOBI on 11/29/2017.
 */
public class food extends shapes {//class food extends shapes

     int radius;

    public food(int pos, int pos1, int radius) {//class constructor
        this.x = pos;//the variable x in the abstract shapes class equals the variable pos  (constructor value)
        this.y = pos1;//the variable y in the abstract shapes class equals the variable pos1 (constructor value)
        this.radius = radius;//the radius variable created in this class equals to the variable radius(constructor value)

    }
}


