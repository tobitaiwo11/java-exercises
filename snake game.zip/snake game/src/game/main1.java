package game;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;

import static game.main1.*;

/**
 * Created by OLUWATOBI on 11/30/2017.
 */

public class main1 extends JFrame {//extend jframe
    food circle;//variable circle contains properties of class food
    snake square;//variable square contains properties of class snake
    enemy ghost;//variable ghost contains properties of class enemy
    enemy2 ghost1;//variable ghost1 contains properties of class enemy2
    enemy3 ghost2;//variable ghost2 contains properties of class enemy3
    enemy4 ghost3;//variable ghost3 contains properties of class enemy3
    JTextField name1;//name1 stores jtextfield values
    String name;//variable stroes string
    Date thedate;//stores date
    int thescore;//stores score
    int c = 0;
    JLabel label;
    int[] b=new int[2];
    int check=0;
     int  start=0;

    static boolean  left=false;//boolean values
    static boolean right=false;
    static boolean up=false;
    static boolean down=false;

    public main1(){//main1 class constructor

        circle=new food((int)(20*Math.random()),(int)(20*Math.random()),17);// snake class is initialized
        square=new snake(10,10);//square class is initialized
        ghost=new enemy(0,0);//ghost class is initialized
        ghost1=new enemy2(0,19);//ghost1 class is initialized
        ghost2=new enemy3(19,19);//ghost2 class is initialized
        ghost3=new enemy4(19,19);//ghost3 class is initialized
        label=new JLabel();
        JButton button=new JButton("start game");//jbutton is initialized
        name1 =new JTextField("",20);

        JPanel panel1=new JPanel();//jpanel is initialized
        panel1.add(name1);//add name1 to panel 1
        panel1.add(button); //add button panel1
        button b1=new button(this,1);
        button.addActionListener(b1);
        JPanel panel2=new JPanel();

        JButton button1=new JButton("all time scores");//button for the all the all time scores
        panel2.add(button1);
        button b2=new button(this,2);
        button1.addActionListener(b2);
        JButton button2=new JButton("scores in the last 24 hours");//button for the scores in the last 24 hours
        button b3=new button(this,3);
        button2.addActionListener(b3);
        panel2.add(button2);



        add(panel1,BorderLayout.NORTH);//panel1 is added borderlayout north
        add(panel2,BorderLayout.SOUTH);//panel1 is added borderlayout south


    }

    public static void main(String[] args) {
        main1 maingame = new main1();// main1 is initialized
        maingame.setTitle("Tobi Tunde Taiwo 1601542");//the frame title is set
        maingame.pack();
        maingame.setVisible(true);
        maingame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// exits when close is pressed


    }}

class game extends JPanel implements ActionListener, KeyListener,MouseListener {//class game extends actionlistiner, keylistener
    Timer t = new Timer(150, this);//time is initialized(controls speed of the ball
    int vel1 = 0;
    int vel2 = 0;
    main1 app; //variable app contains properties of main1


    game(main1 a) {//game constructor
        app = a;
        t.start();
        addKeyListener(this);//keylistener is added to the frame
        addMouseListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);

    }




    public void paintComponent(Graphics g) {//draw graphics
        super.paintComponent(g);
        Graphics2D g1 = (Graphics2D) g;//graphic2d variables
        Graphics2D g2 = (Graphics2D) g;
        Graphics2D g3 = (Graphics2D) g;
        Graphics2D g4 = (Graphics2D) g;
        Graphics2D g5 = (Graphics2D) g;
        Graphics2D g6 = (Graphics2D) g;
        Graphics2D g7 = (Graphics2D) g;
        for (int x = 0; x < 20; x++) {//loop creates 20x20 grid
            for (int y = 0; y < 20; y++) {
                g1.drawRect(x * app.square.width, y * app.square.height, app.square.width, app.square.height);//draws rectangles
            }
        }

        g2.setColor(Color.blue);//color of circle
        g2.drawOval(app.circle.x * app.square.width, app.circle.y * app.square.height, app.circle.radius, app.circle.radius);//draws circle
        g2.fillOval(app.circle.x * app.square.width, app.circle.y * app.square.height, app.circle.radius, app.circle.radius);//fill circle

        if (app.b[0] == app.circle.x && app.b[1] == app.circle.y) {//check if the circle and square have met
            app.square.counter++;
            app.thescore = app.square.counter;
            app.circle.x = (int) (20 * Math.random());//repaints circle at a random position
            app.circle.y = (int) (20 * Math.random());
            g2.drawOval(app.circle.x * app.square.width, app.circle.y * app.square.height, app.circle.radius, app.circle.radius);
            g2.fillOval(app.circle.x * app.square.width, app.circle.y * app.square.height, app.circle.radius, app.circle.radius);
            repaint();
        }

        g3.setColor(Color.red);//color of the square
        if (app.check < 1) {
            for (int i = 0; i < app.square.length1.size(); i++) {
                g3.drawRect(app.square.length1.get(i)[0] * app.square.width, app.square.length1.get(i)[1] * app.square.height, app.square.width, app.square.height);
                g3.fillRect(app.square.length1.get(i)[0] * app.square.width, app.square.length1.get(i)[1] * app.square.height, app.square.width, app.square.height);


                //checks if square and arcs have met
                if (app.square.length1.get(i)[0] == app.ghost.x2 && app.square.length1.get(i)[1] == app.ghost.y2) {
                    app.check++;

                }
                if (app.square.length1.get(i)[0] == app.ghost1.x3 && app.square.length1.get(i)[1] == app.ghost1.y3) {

                    app.check++;


                }
                if (app.square.length1.get(i)[0] == app.ghost2.x4 && app.square.length1.get(i)[1] == app.ghost2.y4) {

                    app.check++;

                }
                if (app.square.length1.get(i)[0] == app.ghost3.x5 && app.square.length1.get(i)[1] == app.ghost3.y5) {
                    app.check++;
                }


            }

            g4.setColor(Color.black);//sets color of arc
            for (int i1 = 0; i1 < 20; i1++) {
                g4.drawArc(app.ghost.x2 * 20, app.ghost.y2 * 20, 20, 20, 30, 300);//creates arc
                g4.fillArc(app.ghost.x2 * 20, app.ghost.y2 * 20, 20, 20, 30, 300);//fills arc

            }
            g5.setColor(Color.yellow);//sets color of arc
            for (int i2 = 0; i2 < 20; i2++) {
                g5.drawArc(app.ghost1.x3 * 20, app.ghost1.y3 * 20, 20, 20, 30, 300);//creates arc
                g5.fillArc(app.ghost1.x3 * 20, app.ghost1.y3 * 20, 20, 20, 30, 300);//fills arc

            }
            g6.setColor(Color.cyan);//set color of arc
            for (int i3 = 0; i3 < 20; i3++) {
                g6.drawArc(app.ghost2.x4 * 20, app.ghost2.y4 * 20, 20, 20, 30, 300);//creates arc
                g6.fillArc(app.ghost2.x4 * 20, app.ghost2.y4 * 20, 20, 20, 30, 300);//fills arc

            }
            g7.setColor(Color.green);// set color of arc
            for (int i4 = 0; i4 < 20; i4++) {
                g7.drawArc(app.ghost3.x5 * 20, app.ghost3.y5 * 20, 20, 20, 30, 300);//ceates arc
                g7.fillArc(app.ghost3.x5 * 20, app.ghost3.y5 * 20, 20, 20, 30, 300);//fills arc

            }
        }
        for (int[] k : app.square.length1) {
            if (app.b == k) {
                app.c++;
            }

        }

    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (app.check < 1) {// if check is less than 1 vel1 and vel2 are added
            app.square.x1 = app.square.x1 + vel1;
            app.square.y1 = app.square.y1 + vel2;
        }
        if (app.square.x1 < 0 || app.square.x1 > 19) {//prevents square from going out the grid
            app.square.x1 = 0;

        }
        if (app.square.y1 < 0 || app.square.y1 > 19) {//prevents square from going out the grid
            app.square.y1 = 0;

        }
        if (app.check == 1) {//if check is 1 game is over
            app.name=app.name1.getText();// gets the text
            app.thedate=new Date();
            JOptionPane.showMessageDialog(null, "game over!" + "\n" + "player:" + app.name + "\n" + "your score:" + app.square.counter + "\n" + "date:" + app.thedate + "\n");
            app.check = 2;
            player det;
            String str;
            if(app.check==2){
                det=new player(app.name,app.square.counter,app.thedate);//player class is initialized
                str=det.toString();
                List<Integer> ar=new ArrayList<>();//arrylist variables
                List<String> ar2 = new ArrayList<>();
                List<String> ar1=new ArrayList<>();
                try {
                    BufferedReader s = new BufferedReader(new FileReader("record.txt"));//files are read from record.txt
                    String line;
                    while ((line = s.readLine()) != null) {
                        ar1.add(line);
                    }
                    ar1.add(str);
                    for (int c = 0; c < ar1.size(); c++) {//scores added into a list
                        String rec = ar1.get(c);
                        String[] rec1=rec.split(",");
                        ar.add(Integer.parseInt(rec1[1]));

                    }
            Collections.sort(ar);//arrylis of scores are sorted in order
                    Collections.reverse(ar);
            for(int i=0;i<ar.size();i++) {//this is used to arrange the fill from the player with the highest score to the lowest
                for(int j=0;j<ar1.size();j++){
                    String m=Integer.toString(ar.get(i));
                    String rec2=ar1.get(j);
                    String[] rec3=rec2.split(",");
                    String rec4=rec3[1];
                    if(m.equals(rec4)){
                        ar2.add(rec2);
                        System.out.println(rec2);
                    }
                }

            }
            Set s2=new LinkedHashSet(ar2);
            ar2=new ArrayList<>(s2);

            } catch (FileNotFoundException e1) {
                JOptionPane.showMessageDialog(null,"file not found");//displayed when file is not found
            } catch (IOException e1) {
                e1.printStackTrace();
            }
                try {
                    PrintWriter op=new PrintWriter("record.txt");//writes sorted list into text file
                    for(String k:ar2){
                    op.println(k);
                    }
                    op.close();
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                }
            }}
        app.ghost.y2 = app.ghost.y2 + 1;//places arc at random positions
        if (app.ghost.y2 == 20) {
            app.ghost.x2 = (int) (20 * Math.random());
            app.ghost.y2 = 0;
        }
        app.ghost1.x3 = app.ghost1.x3 + 1;//places arc at random positions
        if (app.ghost1.x3 == 20) {
            app.ghost1.y3 = (int) (20 * Math.random());
            app.ghost1.x3 = 0;
        }
        app.ghost2.x4 = app.ghost2.x4 - 1;//places arc at random positions
        if (app.ghost2.x4 == 0) {
            app.ghost2.y4 = (int) (20 * Math.random());
            app.ghost2.x4 = 19;
        }
        app.ghost2.x4 = app.ghost2.x4 - 1;//places arc at random positions
        if (app.ghost2.x4 == 0) {
            app.ghost2.y4 = (int) (20 * Math.random());
            app.ghost2.x4 = 19;
        }
        app.ghost3.y5 = app.ghost3.y5 - 1;//places arc at random positions
        if (app.ghost3.y5 == 0) {
            app.ghost3.x5 = (int) (20 * Math.random());
            app.ghost3.y5 = 19;
        }

        app.b[0] = app.square.x1;
        app.b[1] = app.square.y1;
        app.square.length.add(app.b);
        Set set = new LinkedHashSet(app.square.length);
        app.square.length1 = new ArrayList<>(set);
        repaint();
    }


    @Override
    public void keyPressed(KeyEvent e) {

        int c = e.getKeyCode();//if the right key is pressed vel=1
        if (c == KeyEvent.VK_RIGHT) {
            vel1 = 1;
            vel2 = 0;
            right = true;


        }
        if (c == KeyEvent.VK_LEFT) {//if the left key is pressed vel1=-1
            vel1 = -1;
            vel2 = 0;

            left = true;
        }
        if (c == KeyEvent.VK_UP) {//if the up key is pressed ve2=-1
            vel1 = 0;
            vel2 = -1;
            up = true;
        }

        if (c == KeyEvent.VK_DOWN) {//if the down key is pressed vel2=1
            vel1 = 0;
            vel2 = 1;
            down = true;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}

class button implements ActionListener {//button i,plements actionlistiner
    main1 m;//variable m contains properties of main1
    int num;
    public button(main1 x, int n){//button constructor
        m=x;
        num=n;

    }
    public void actionPerformed(ActionEvent e) {

        if(num==1){ //if the variable num equals to 1
            m.start++;
            m.setSize(500,700);
            if(m.name1.equals("")){//if the the text field is empty
                JOptionPane.showMessageDialog(null,"you cant start the game without a name");
            }else {
                game panel=new game(m);
                m.add(panel);
            }

        }
        if(num==2){
            List<String>list=new ArrayList<String>();//array list variables
            List<String>list1=new ArrayList<String>();
            try {

                BufferedReader s1 = new BufferedReader(new FileReader("record.txt"));//reads text file
                    String line;
                    while ((line = s1.readLine()) != null) {
                        list.add(line);

                    }
                    s1.close();
                    for(int i=0;i<10;i++){
                        list1.add(list.get(i));
                    }
                int c=0;
                for(String k:list1){//shows ranking and the player details
                    c++;
                    JOptionPane.showMessageDialog(null,"format:rank/name/score/date and time "+"ranking: "+c+","+k+"\n");
                }

                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();

        } catch (IOException e1) {
                e1.printStackTrace();
            }

        }
        if(num==3){
            List<String>list=new ArrayList<String>();//array list variables
            List<String>list1=new ArrayList<String>();
            try {

                BufferedReader s1 = new BufferedReader(new FileReader("record.txt"));//reads text file
                String line;
                while ((line = s1.readLine()) != null) {

                    String[] line1=line.split(",");
                    String date=line1[2];
                    String date1=date.substring(0,10);
                    list.add(date1);
                    list1.add(line);

                }
                s1.close();

                int c=0;
                for(String k:list){
                    c++;
                    for(String k1:list1){
                        if(k1.contains(k)){
                            JOptionPane.showMessageDialog(null,"format:rank/name/score/date and time "+"ranking: "+c+","+k1+"\n");
                            if(c==10){
                                break;
                            }
                        }
                        }
                    }

            } catch (FileNotFoundException e1) {
                e1.printStackTrace();

            } catch (IOException e1) {
                e1.printStackTrace();
            }


        }
}}



