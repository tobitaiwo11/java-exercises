package game;

/**
 * Created by OLUWATOBI on 11/29/2017.
 */
public class snake extends shapes {//the snake class extends the shape class
    int width = 20;//variables
    int height = 20;

    public snake(int x, int y){//constructor snakes takes 2 values
        this.x1=x;//x1 of the abstract class shape equals to x(constructor value)
        this.y1=y;//y1 of the abstract class shape equals to y(constructor value)
    }


}
