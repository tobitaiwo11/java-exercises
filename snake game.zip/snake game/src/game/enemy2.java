package game;

/**
 * Created by OLUWATOBI on 12/9/2017.
 */

public class enemy2 extends shapes {//the class enemy2 extends the abstract class shape
    public enemy2(int x, int y){//the constructor enemy2 take 2 values
        this.x3=x;//the values of x3 which is in the abstract class is equals to x(constructor value)
        this.y3=y;//the values of y3 which is in the abstract class is equals to y(constructor value)
    }
}
