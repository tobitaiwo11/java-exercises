package fivebyfive;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by OLUWATOBI on 11/15/2017.
 */
class Point {
public int x;//variables
public int y;

public Point(int x, int y) {//constructor is used in this class
        this.x = x;
        this.y = y;
        }

@Override
public String toString() {
        return "[" + (x+1) + ", " + (y+1) + "]";
        } //returns x+1 and y+1 in string
        }

class PointsAndScores {
    int score;
    Point point;

    PointsAndScores(int score, Point point) {
        this.score = score;
        this.point = point;
    }
}

class Board {//class board
    static List<Point> availablePoints;//list called availablepoints stores values of type point
    Scanner scan = new Scanner(System.in);//scanner used for inputing values
    static int[][] board = new int[5][5];//double arrayof length 3;
    Point cm;//cm is a variable of type Point


    public Board() {//board is made public
    }

    public boolean isGameOver() {
        return (hasXWon(1) || hasOWon(2) || getAvailablePoints().isEmpty());
    }//game is over
    //if x(ai player) has won or o(the user) has won or the list getAvailablepoints is empty

    public boolean hasXWon(int b) {//x has won
        if ((board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] == board[3][3] && board[0][0] == board[4][4] && board[0][0] == 1) ||
                (board[0][4] == board[1][3] && board[0][4] == board[2][2] && board[0][4] == board[3][1] && board[0][4] == board[4][0] && board[0][4] == 1)) {
            return true;//diagonal
        }
        for (int i = 0; i < 5; ++i) {//checks rows
            if (((board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] == board[i][3] && board[i][0] == board[i][4] && board[i][0] == 1)
                    || (board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] == board[3][i] && board[0][i] == board[4][i] && board[0][i] == 1))) {
                return true;//checks columns
            }
        }
        return false;
    }

    public boolean hasOWon(int a) {//check if o has won
        if ((board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] == board[3][3] && board[0][0] == board[4][4] && board[0][0] == 2) ||
                (board[0][4] == board[1][3] && board[0][4] == board[2][2] && board[0][4] == board[3][1] && board[0][4] == board[4][0] && board[0][4] == 2)) {
            return true;// checks diagonals
        }
        for (int i = 0; i < 5; ++i) {
            if (((board[i][0] == board[i][1] && board[i][0] == board[i][2] && board[i][0] == board[i][3] && board[i][0] == board[i][4] && board[i][0] == 2)//checks rows
                    || (board[0][i] == board[1][i] && board[0][i] == board[2][i] && board[0][i] == board[3][i] && board[0][i] == board[4][i] && board[0][i] == 2))) {//checks columns
                return true;
            }
        }
        return false;
    }

    public List<Point> getAvailablePoints() {//methode that gets values of type list
        availablePoints = new ArrayList<>();//list
        for (int i = 0; i < 5; ++i) {//for loop used fill array
            for (int j = 0; j < 5; ++j) {
                if (board[i][j] == 0) {
                    availablePoints.add(new Point(i, j));
                }
            }
        }

        return availablePoints; //returns list of point
        }

    public int getState(Point point) {
        return board[point.x][point.y];
    }

    public boolean placeAMove(Point point, int player) {//places 1(ai player) or 2(user) in a position in the board array
        if (board[point.x][point.y] != 0) {
            return false;
        }
        board[point.x][point.y] = player;
        return true;
    }

    public void displayBoard() {
        System.out.println();

        for (int i = 0; i < 5; ++i) {//for loop goes through board array and uses x or o or . to represent values in the array
            for (int j = 0; j < 5; ++j) {
                if (board[i][j] == 1)
                    System.out.print("X ");
                else if (board[i][j] == 2)
                    System.out.print("O ");
                else
                    System.out.print(". ");
            }
            System.out.println();
        }
    }

    public int alphabeta(int root, int turn, int alpha, int beta) {// reference how to use alpha beta from youtube but didnt work the way i wanted it to

        if (hasXWon(1)) {// check if ai player won
            return 1;
        }
        if (hasOWon(2)) {//check if user has won
            return -1;
        }
        List<Point> ap = getAvailablePoints();
        if (ap.isEmpty()) {//check if the list of available points
            return 0;
        }

        int minimum = Integer.MAX_VALUE;//
        int maximum = Integer.MIN_VALUE;
        for (int i = 0; i < ap.size(); i++) {
            Point p = ap.get(i);
            if (turn == 1) {
                placeAMove(p, 1);
                int currents = alphabeta(root + 1, 2, alpha, beta);
                if (currents > alpha) {
                    alpha = currents;//alpha becomes current
                }
                if (alpha >= beta) {//if the value of alpha is greater than beta stop
                    break;
                }

                maximum = Math.max(alpha, maximum);
                if (root == 0) {
                    System.out.println(p + "+" + alpha);
                }
                if (maximum >= 0) {

                    if (root == 0) {
                        cm = p;
                    }
                }
                if (maximum== 1) {
                    board[p.x][p.y] = 0;
                    break;
                }
                if (i == ap.size() - 1 && maximum < 0) {
                    if (root == 0)
                        cm = p;
                }

            } else if (turn == 2) {
                placeAMove(p, 2);
                int currents = alphabeta(root + 1, 1, alpha, beta);
                if(currents<beta){
                    beta=currents;
                }
                if(alpha>=beta){
                    break;}

                minimum = Math.min(beta, minimum);
                if (minimum == -1) {
                    board[p.x][p.y] = 0;
                    break;
                }
            }
            board[p.x][p.y] = 0;
        }
        return turn == 1 ? maximum : minimum;
        //alpha beta method puring is used with minimax
    }
}
