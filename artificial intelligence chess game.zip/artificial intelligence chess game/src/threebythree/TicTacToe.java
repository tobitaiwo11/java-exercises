package threebythree;//Commenting is not done deliberately

import java.util.*;

public class TicTacToe {



    public static void main(String[] args) {// main class

        Board b = new Board();//initializes board
        Point p = new Point(0, 0);//initializes point
        Random rand = new Random();// random numbers


        b.displayBoard();//display board

        System.out.println("Who makes first move? (1)Computer (2)User: ");//ask who plays first
        int choice = b.scan.nextInt();//input a value
        if(choice==1) {
            p.x = rand.nextInt(3);
            p.y = rand.nextInt(3);
            b.placeAMove(p, 1);
            b.displayBoard();
        }

        while (!b.isGameOver()) {//if the game is not over
            boolean move = true;


            do {
                if (!move) {//if move is false
                    System.out.println("filled");
                }
                System.out.println("Your move: line (1, 2, or 3) colunm (1, 2, or 3)");
                Point userMove = new Point(b.scan.nextInt() - 1, b.scan.nextInt() - 1);//enter the users moves
                move = b.placeAMove(userMove, 2);
                System.out.println(userMove);
                while (b.getState(userMove) == 0) {// invalid move if user enters a number greater than 3
                    System.out.println("Invalid move. Make your move again: ");
                    userMove.x = b.scan.nextInt() - 1;
                    userMove.y = b.scan.nextInt() - 1;
                }

            } while (!move);
            {
                b.displayBoard();
            }

            if (b.isGameOver()) {//end game if x(ai player) has won or o(the user) has won or the list getAvailablepoints is empty

                break;
            }
            b.minimax(0, 1);//minmax
            b.placeAMove(b.cm,1);
            b.displayBoard();


        }

            if (b.hasXWon(1)) {
                System.out.println("Unfortunately, you lost!");
            } else if (b.hasOWon(2)) {
                System.out.println("You win!");
            } else {
                System.out.println("It's a draw!");
            }
        }

    }